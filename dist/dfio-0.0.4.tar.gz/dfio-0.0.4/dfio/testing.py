import os

def execute_local_cf_test_with_pubsub_payload(path_to_payload_json: str):



    pass
# dfio `(datafunctions input/output)`

This package simplifies a number of core functions associated with building simple, scalable SQL-based data transformation pipelines.

See [datafunctions.github.io](https://datafunctions.github.io) for full documentation.